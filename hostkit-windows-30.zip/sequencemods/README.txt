SequenceMods host package for The Isle dedicated servers
========================================================

This zip is the same for every host and every server. Nothing in it is tied to
one host, one server or one owner, and it does nothing until a server's owner
gives the server its key.

Install
-------
1. Stop the server.
2. Extract the zip into the game server folder (the folder that holds TheIsle),
   replacing files that are already there.
3. Linux only: set the server's LD_PRELOAD startup variable to the line in
   TheIsle/Saved/SequenceMods/package/PRELOAD.txt, with <ROOT> replaced by the
   server folder (/home/container on a Pterodactyl egg). An egg that already has
   a MOD_PRELOAD variable takes the same line there.
   Windows only: nothing more to do. The file TheIsle/Binaries/Win64/dwmapi.dll
   is what loads the package. A server that already has its own dwmapi.dll there
   (a mod loader) gets it replaced, and that loader no longer starts.
4. Start the server as usual.

Extract while the server is stopped: a running game may crash when its files are
replaced, and Windows will not replace a file the game has loaded.

Off until the owner connects it
-------------------------------
With the package in place and no key, the server runs as the plain game: no file
is written and nothing connects anywhere. Once the map has loaded, the console
shows one line that says how to connect.

Connecting (what the owner does)
--------------------------------
1. In the SequenceMods Hub, the owner presses Connect on the server and copies
   the key it shows.
2. The owner pastes the key into the server's startup setting SEQUENCEMODS_KEY
   and restarts the server. A panel with no startup settings takes the key in
   this empty file already included in the zip:

    TheIsle/Saved/SequenceMods/key.txt

3. The server connects as it starts, before the map has loaded, and the Hub
   shows it as Connected. The key works once, within an hour of the press. A
   used key left in place does nothing, and the server stays connected if it is
   taken out.

A key that does not work gives one console line that says why. Get a new key
from Connect in the Hub and restart.

If the server stopped twice within half an hour before its map had loaded, the
package rests for 30 minutes to keep the server safe and the game runs without
it. Start the server again 30 minutes after the last stop.

For a host: a startup setting named SEQUENCEMODS_KEY that reaches the game as an
environment variable is all the package needs.

What the package never touches
------------------------------
Game settings (Game.ini, Engine.ini, GameUserSettings.ini), player saves, game
logs, the game program and its content, SteamCMD files, your start scripts and
any mod loader of the owner's. Every file it adds is under these three paths:

    TheIsle/Saved/SequenceMods/
    sequencemods/
    TheIsle/Binaries/Win64/dwmapi.dll   (Windows only)

Recommended startup flags (optional)
------------------------------------
Because the package never edits your start scripts or Engine.ini, hosts may
optionally add the official UE5 server flags to their game startup line:

    -useperfthreads -NoAsyncLoadingThread

Updating
--------
A connected server updates itself: every new version arrives over its
connection, signed by SequenceMods, and takes effect at the server's next
restart. A version that fails its first start is rolled back by itself.
Nothing is installed again by hand. Extracting a newer zip over the old one
(server stopped) also works, and a connected server stays connected: the zip
never holds a server's own keys, connection or settings.

Disconnecting or removing it
----------------------------
Disconnect: press Disconnect on the server in the Hub. A new key from Connect
connects it again.
Remove: also remove the LD_PRELOAD line (Linux) or delete
TheIsle/Binaries/Win64/dwmapi.dll (Windows), then delete the folders
TheIsle/Saved/SequenceMods and sequencemods. That also deletes the server's own
key and connection: installed again, it needs a new key from Connect.

Checking the download
---------------------
Each zip has a .sha256 file beside it. Inside the zip,
TheIsle/Saved/SequenceMods/package/MANIFEST.json lists every file with its
sha256 and is signed by SequenceMods.
